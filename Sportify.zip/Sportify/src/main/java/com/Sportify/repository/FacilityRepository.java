package com.Sportify.repository;

import com.Sportify.model.Facility;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacilityRepository extends JpaRepository<Facility, Long> {
    // Custom query methods can be defined here
	
	Facility findById(long facilityId);
}
