package com.Sportify.controller;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.Model;
import com.Sportify.model.Player;
import com.Sportify.service.PlayerService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/player")
public class PlayerController {
	@Autowired
	private PlayerService playerService;

	@GetMapping("")
	public ModelAndView index() {
		return new ModelAndView("home");
	}

	@GetMapping("/login")
	public ModelAndView login() {
		return new ModelAndView("loginnew");
	}

	@GetMapping("/logout")
	public ModelAndView logout(HttpSession session) {
		session.invalidate();
		return new ModelAndView("loginnew");
	}

	@GetMapping("/register")
	public ModelAndView register() {
		return new ModelAndView("register");
	}

	@PostMapping("/create")
	public ModelAndView createPlayer(Player player) {
		Random random = new Random();
		int number = random.nextInt(900) + 100;
		String pID = "MS-" + number;
		player.setPlayerID(pID);
		if (playerService.checkIfExists(player)) {
			return new ModelAndView("loginnew");
		}
		Player createdPlayer = playerService.createPlayer(player);
		return new ModelAndView("loginnew");
	}

	
	  @PostMapping("/check")
	  public ModelAndView loginPlayer(Player player, HttpSession session){ 
		  
       ModelAndView view = new ModelAndView();
	  
	  Player existing = playerService.validate(player);
	  if (existing == null)
	  {
	  view.setViewName("loginnew");
	  view.addObject("message","Invalid Credentials! Please try again.");
	  }
	  else {
		 view.setViewName("home");
	     view.addObject("player",existing);
	   session.setAttribute("play", existing);
	   session.setAttribute("playId", existing.getPlayerID());
	 
	  }
	  return view;
	  }
	
//	@PostMapping("/check")
//	public String loginPlayer(Player player, HttpSession session, Model model) {
//		System.out.print(player);
//		Player existing = playerService.validate(player);
//		System.out.print(existing);
//		if (existing == null) {
//			model.addAttribute("message", "Invalid Credentials! Please try again.");
//			return "loginnew";
//		} else {
//			model.addAttribute("player", existing);
//			session.setAttribute("play", existing);
//			session.setAttribute("playId", existing.getPlayerID());
//
//			// Redirect to /bookFacality with player ID as query parameter
//			return "redirect:/bookFacality";
//		}
//	}

	@GetMapping("/update/{playerId}")
	public ModelAndView updateView(@PathVariable String playerId) {
		ModelAndView mView = new ModelAndView("profile");

		Optional<Player> optionalPlayer = playerService.getPlayerByPlayerId(playerId);
		if (optionalPlayer.isPresent()) {
			mView.addObject("player", optionalPlayer.get());
		}

		return mView;
	}

	@PostMapping("/updatePlayer")
	public ModelAndView updateProfile(Player player) {
		ModelAndView mView = new ModelAndView("home");

		Optional<Player> optionalPlayer = playerService.getPlayerByPlayerId(player.getPlayerID());
		if (optionalPlayer.isPresent()) {
			Player existingPlayer = optionalPlayer.get();

			existingPlayer.setContactNumber(player.getContactNumber());
			existingPlayer.setEmail(player.getEmail());
			existingPlayer.setUserPassWord(player.getUserPassWord());
			existingPlayer.setAddress(player.getAddress());
			existingPlayer.setState(player.getState());

			playerService.createPlayer(existingPlayer);
		}
		mView.addObject("msg", "Profile Updated!");
		return mView;
	}

}
