package com.Sportify.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;

    @ManyToOne
    @JoinColumn(name = "facility_id")
    private Facility facility;

    @ManyToOne
    @JoinColumn(name = "player_id")
    private Player player;

		public Booking() {
			// TODO Auto-generated constructor stub
		}

    public Booking(Facility facility, Player player) {
		super();
		this.facility = facility;
		this.player = player;
	}

	public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Facility getFacility() {
        return facility;
    }

    public void setFacility(Facility facility) {
        this.facility = facility;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", facility=" + facility + ", player=" + player + "]";
	}



    
}
