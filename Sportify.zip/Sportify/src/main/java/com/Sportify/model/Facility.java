package com.Sportify.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "facilities")
public class Facility {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long facilityId;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "sport")
    private String sport;

    @Column(name = "graoundNo")
    private String graoundNo;

    @Column(name = "slot")
    private String slot;
    

	@Column(name = "status")
    private boolean status;

    // Getters and Setters
    public long getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(long facilityId) {
        this.facilityId = facilityId;
    }
    
    public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getSport() {
        return sport;
    }

    public void setSport(String sport) {
        this.sport = sport;
    }

  

    public String getGraoundNo() {
		return graoundNo;
	}

	public void setGraoundNo(String graoundNo) {
		this.graoundNo = graoundNo;
	}

	public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }

	@Override
	public String toString() {
		return "Facility [facilityId=" + facilityId + ", date=" + date + ", sport=" + sport + ", graoundNo=" + graoundNo
				+ ", slot=" + slot + ", status=" + status + "]";
	}
	
    
}

