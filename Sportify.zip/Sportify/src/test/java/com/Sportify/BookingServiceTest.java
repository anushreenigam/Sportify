package com.Sportify;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.Sportify.model.Facility;
import com.Sportify.model.Booking;
import com.Sportify.service.BookingService;
import com.Sportify.service.FacilityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

class BookingServiceTest {

    @InjectMocks
    private BookingService bookingService;

    @Mock
    private FacilityService facilityService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void filterAvailableSlotsBySportAndDate() {
        Facility facility1 = new Facility();
        facility1.setSport("Football");
        facility1.setDate(LocalDate.of(2023, 5, 20));
        facility1.setStatus(false);

        Facility facility2 = new Facility();
        facility2.setSport("Badminton");
        facility2.setDate(LocalDate.of(2023, 5, 20));
        facility2.setStatus(false);

        List<Facility> facilities = Arrays.asList(facility1, facility2);

        when(facilityService.getAllFacilities()).thenReturn(facilities);

        List<Facility> result = bookingService.filterAvailableSlotsBySportAndDate("Football", LocalDate.of(2023, 5, 20));

        assertEquals(1, result.size());
        assertEquals("Football", result.get(0).getSport());
    }
}
