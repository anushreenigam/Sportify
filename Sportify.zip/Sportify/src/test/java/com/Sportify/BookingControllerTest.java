package com.Sportify;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.Sportify.model.Facility;
import com.Sportify.model.Booking;
import com.Sportify.service.BookingService;
import com.Sportify.controller.BookingController;
import com.Sportify.service.FacilityService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(BookingController.class)
class BookingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private BookingService bookingService;

    @Mock
    private FacilityService facilityService;

    @InjectMocks
    private BookingController bookingController;

    @SuppressWarnings("deprecation")
	@BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void searchAvailableSlots() throws Exception {
        Facility facility1 = new Facility();
        facility1.setSport("Football");
        facility1.setDate(LocalDate.of(2023, 5, 20));
        facility1.setStatus(false);

        List<Facility> facilities = Arrays.asList(facility1);

        when(bookingService.filterAvailableSlotsBySportAndDate("Football", LocalDate.of(2023, 5, 20)))
                .thenReturn(facilities);

        mockMvc.perform(get("/bookings/searchSlots")
                .param("date", "2023-05-20")
                .param("sport", "Football"))
                .andExpect(status().isOk())
                .andExpect(view().name("searchAvailableSlots"))
                .andExpect(model().attributeExists("facilities"))
                .andExpect(model().attribute("facilities", facilities));
    }
}
