package com.Sportify.model;

import java.time.LocalDate;

import jakarta.persistence.*;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="player")
public class Player {
	@Id
	/* @GeneratedValue(strategy = GenerationType.AUTO) */
	@Column(name="playerID")
	private String playerID;
	@Column(name="userPassWord")
    private String userPassWord;
	@Column(name="name")
    private String name;
	@Column(name="email")
    private String email;
	@Column(name="contactNumber")
    private String contactNumber;
	@Column(name="pancardNumber")
    private String pancardNumber;
	@Column(name="dob")
    private LocalDate dob;
	@Column(name="address")
    private String address;
	@Column(name="state")
    private String state;
    
	public Player(String playerID, String userPassWord, String name,
			String email, String contactNumber, String pancardNumber, LocalDate dob, String address, String state) {
		super();
		this.playerID = playerID;
		this.userPassWord = userPassWord;
		this.name = name;
		this.email = email;
		this.contactNumber = contactNumber;
		this.pancardNumber = pancardNumber;
		this. dob=dob;
		this.address=address;
		this.state=state;
		
	}

	public Player() {
		super();
	}

	public String getPlayerID() {
		return playerID;
	}

	public void setPlayerID(String playerID) {
		this.playerID= playerID;
	}

	public String getUserPassWord() {
		return userPassWord;
	}

	public void setUserPassWord(String userPassWord) {
		this.userPassWord = userPassWord;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getPancardNumber() {
		return pancardNumber;
	}

	public void setPancardNumber(String pancardNumber) {
		this.pancardNumber = pancardNumber;
	}
	
	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = address;
	}

	@Override
	public String toString() {
		return "Player [playerID=" + playerID + ", userPassWord=" + userPassWord + ", name=" + name + ", email=" + email
				+ ", contactNumber=" + contactNumber + ", pancardNumber=" + pancardNumber + ", dob=" + dob
				+ ", address=" + address + ", state=" + state + "]";
	}
	
    

}