package com.Sportify.controller;

import com.Sportify.model.Booking;
import com.Sportify.model.Facility;
import com.Sportify.model.Player;
import com.Sportify.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import com.Sportify.service.FacilityService;
import com.Sportify.service.PlayerService;

import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	private FacilityService facilityService;

	@Autowired
	private PlayerService playerService;

	@GetMapping("/bookFacility")
	public ModelAndView showBookingForm() {
		ModelAndView mav = new ModelAndView("joinFacility");
		mav.addObject("facilities", facilityService.getAvailableFacilities());
		mav.addObject("booking", new Booking());
		return mav;
	}
//    @GetMapping("/searchSlots")
//    public ModelAndView findAvailableSlots(@RequestParam(value = "date", required = false) String date, @RequestParam(value = "sport", required = false) String sport) {
//        ModelAndView mav = new ModelAndView("searchAvailableSlots");
//
//        List<Facility> facilities;
//        if (date == null && sport == null) {
//            facilities = facilityService.getAvailableFacilities();
//        } else {
//            LocalDate localDate = date != null && !date.isEmpty() ? LocalDate.parse(date) : null;
//            facilities = bookingService.filterAvailableSlotsBySportAndDate(sport, localDate);
//        }
//
//        mav.addObject("facilities", facilities);
//        return mav;
//    }

	
	  @GetMapping("/createBooking/{facilityId}")
	  public ModelAndView createBooking(@PathVariable Long facilityId,HttpSession session) {
		  
		  if(session.getAttribute("play")==null) {
				return new ModelAndView("loginnew");
			} 
		  ModelAndView mav = new ModelAndView("bookingResult");
//		  ModelAndView mav = new ModelAndView("redirect:/bookFacility");
		  
	  try {
	  Player play =  (Player)session.getAttribute("play");
	  Facility facility =  facilityService.getFacilityById(facilityId);
	  facility.setStatus(true);
	  facilityService.saveFacility(facility);
	  
	  Booking booking =  new Booking( facility,play );
	  bookingService.createBooking(booking);
	  mav.addObject("booking", booking);
	  mav.addObject("message","Booking created successfully");
	  }
	 catch (IllegalArgumentException e) {
	  mav.addObject("message", e.getMessage());
	  }
	 return mav;
	 }
	  
	    @GetMapping("/searchSlots")
	    public ModelAndView searchAvailableSlots(@RequestParam("date") LocalDate date, @RequestParam("sport") String sport) {
	        ModelAndView mav = new ModelAndView("joinFacility");

//	        LocalDate localDate = date != null && !date.isEmpty() ? LocalDate.parse(date) : null;
	        List<Facility> facilities = bookingService.filterAvailableSlotsBySportAndDate(sport, date);
	        mav.addObject("facilities", facilities);
	        return mav;
	    }

	@GetMapping("/{bookingId}")
	public ModelAndView getBookingById(@PathVariable Long bookingId) {
		ModelAndView mav = new ModelAndView("booking-details");
		Optional<Booking> booking = bookingService.getBookingById(bookingId);
		if (booking.isPresent()) {
			mav.addObject("booking", booking.get());
		} else {
			mav.addObject("message", "Booking not found");
		}
		return mav;
	}

//	@GetMapping
//	public ModelAndView getAllBookings() {
//		ModelAndView mav = new ModelAndView("booking-list");
//		List<Booking> bookings = bookingService.getAllBookings();
//		mav.addObject("bookings", bookings);
//		return mav;
//	}
//
//	@PostMapping("/delete/{bookingId}")
//	public ModelAndView deleteBooking(@PathVariable Long bookingId) {
//		bookingService.deleteBooking(bookingId);
//		ModelAndView mav = new ModelAndView("redirect:/bookings");
//		return mav;
//	}
}
