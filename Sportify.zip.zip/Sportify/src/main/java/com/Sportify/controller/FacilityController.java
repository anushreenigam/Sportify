package com.Sportify.controller;

import com.Sportify.model.Facility;
import com.Sportify.service.FacilityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import org.springframework.stereotype.Controller;


@Controller
@RequestMapping("/facilities")
public class FacilityController {

    @Autowired
    private FacilityService facilityService;

    @GetMapping
    public ModelAndView getAllFacilities() {
        ModelAndView mav = new ModelAndView("facility-list");
        List<Facility> facilities = facilityService.getAllFacilities();
        mav.addObject("facilities", facilities);
        return mav;
    }

//    @GetMapping("/{facilityId}")
//    public ModelAndView getFacilityById(@PathVariable Long facilityId) {
//        ModelAndView mav = new ModelAndView("facility-details");
//        Optional<Facility> facility = facilityService.getFacilityById(facilityId);
//        if (facility.isPresent()) {
//            mav.addObject("facility", facility.get());
//        } else {
//            mav.addObject("message", "Facility not found");
//        }
//        return mav;
//    }

    @GetMapping("/new")
    public ModelAndView showFacilityForm() {
    	return new ModelAndView("FacilityCreate");
    }

    @PostMapping("/create")
    public ModelAndView createFacility(Facility facility) {
    	facility.setStatus(false);
        facilityService.saveFacility(facility);  
        return new ModelAndView("FacilityCreate");
    }

    @PostMapping("/delete/{facilityId}")
    public ModelAndView deleteFacility(@PathVariable Long facilityId) {
        facilityService.deleteFacility(facilityId);
        ModelAndView mav = new ModelAndView("redirect:/facilities");
        return mav;
    }
}
