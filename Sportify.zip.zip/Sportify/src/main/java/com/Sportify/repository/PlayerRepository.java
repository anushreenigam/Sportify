package com.Sportify.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Sportify.model.Player;

@Repository
public interface PlayerRepository extends JpaRepository<Player, String>

{
	
	public Optional<Player> findById(String playerID);
	
	public void deleteById(String playerID);
	
	public Optional<Player> findByEmail(String email);
	
    public Optional<Player> findByPancardNumber(String pancardNumber);
	
	public Optional<Player> findByContactNumber(String contactNumber);
	

}
