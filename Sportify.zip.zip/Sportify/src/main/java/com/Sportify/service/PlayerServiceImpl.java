package com.Sportify.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Sportify.model.Player;
import com.Sportify.repository.PlayerRepository;
@Service
public class PlayerServiceImpl implements PlayerService {
	
	@Autowired
	private PlayerRepository playerRepository;

	@Override
	public Player createPlayer(Player player) {
		// TODO Auto-generated method stub
		return playerRepository.save(player);
	}
	
	@Override
	public Player validate(Player player) {
		Optional<Player> optionalPlayer=playerRepository.findByEmail(player.getEmail());
		if (optionalPlayer.isPresent()) {
			if (optionalPlayer.get().getUserPassWord().equals(player.getUserPassWord())){
				return optionalPlayer.get();
				
			}
		}
		return null;
		
	}

	@Override
	public List<Player> getAllPlayers() {
		// TODO Auto-generated method stub
		return playerRepository.findAll();
	}


	@Override
	public Optional<Player> getPlayerByPlayerId(String playerID) {
		// TODO Auto-generated method stub
		return playerRepository.findById(playerID);
	}


	@Override
	public Player updatePlayer(String playerID, Player player) {
		// TODO Auto-generated method stub
		Optional<Player> existingPlayerOptional = playerRepository.findById(playerID);

        if (existingPlayerOptional.isPresent()) {
            Player existingPlayer = existingPlayerOptional.get();
            existingPlayer.setUserPassWord(player.getUserPassWord());
            existingPlayer.setEmail(player.getEmail());
            existingPlayer.setContactNumber(player.getContactNumber());
            existingPlayer.setPancardNumber(player.getPancardNumber());
            existingPlayer.setAddress(player.getAddress());
            existingPlayer.setState(player.getState());

            return playerRepository.save(existingPlayer);
        } else {
            
            return null; 
        }
	}

//	@Override
//	public void deletePlayer(String userName) {
//		// TODO Auto-generated method stub
//		playerRepository.deleteByUserName(userName);
//
//	}

	@Override
	public void deletePlayer(String playerID) {
		// TODO Auto-generated method stub
		playerRepository.deleteById(playerID);

	}

	@Override
	public boolean checkIfExists(Player player) {
		// TODO Auto-generated method stub
		
		if(playerRepository.findById(player.getPlayerID()).isPresent()) {
			return true;
		}
		if(playerRepository.findByEmail(player.getEmail()).isPresent()) {
			return true;
		}
		if(playerRepository.findByPancardNumber(player.getPancardNumber()).isPresent()) {
			return true;
		}
		if(playerRepository.findByContactNumber(player.getContactNumber()).isPresent()) {
			return true;
		}
		
		return false;
	}

}
