package com.Sportify.service;

import java.util.List;
import java.util.Optional;


import com.Sportify.model.Player;

public interface PlayerService {
	Player createPlayer (Player player);
	
	boolean checkIfExists(Player player);
	
	List<Player> getAllPlayers();
	
	Optional<Player> getPlayerByPlayerId(String playerID);
	
	Player updatePlayer(String playerID, Player player);
	
	void deletePlayer(String playerID);
	
	Player validate(Player player);

}

