package com.Sportify.service;

import com.Sportify.model.Facility;
import com.Sportify.repository.FacilityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FacilityService {

    @Autowired
    private FacilityRepository facilityRepository;

    public Facility saveFacility(Facility facility) {
        return facilityRepository.save(facility);
    }

    public Facility getFacilityById(long facilityId) {
        return facilityRepository.findById(facilityId);
    }
    
    

    public List<Facility> getAllFacilities() {
        return facilityRepository.findAll();
    }

    public List<Facility> getAvailableFacilities() {
        return facilityRepository.findAll()
                .stream()
                .filter(facility -> !facility.isStatus())
                .collect(Collectors.toList());
    }
    
    
    public void deleteFacility(long facilityId) {
        facilityRepository.deleteById(facilityId);
    }
    
    
}
