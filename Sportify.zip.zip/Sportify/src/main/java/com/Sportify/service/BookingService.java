package com.Sportify.service;

import com.Sportify.model.Booking;
import com.Sportify.model.Facility;

import java.util.Optional;
import java.util.stream.Collectors;

import com.Sportify.repository.BookingRepository;
import com.Sportify.repository.FacilityRepository;
import com.Sportify.repository.PlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private FacilityRepository facilityRepository;

    @Autowired
    private PlayerRepository playerRepository;
    
    @Autowired
    private FacilityService facilityService;

    public Booking createBooking(Booking booking) {
       
        return bookingRepository.save(booking);
    }
    
    public List<Facility> filterAvailableSlotsBySportAndDate(String sport, LocalDate date) {
        List<Facility> allAvailableSlots = facilityService.getAvailableFacilities();

        return allAvailableSlots.stream()
                .filter(facility -> (facility.getSport().equalsIgnoreCase(sport)) &&
                                    (facility.getDate().equals(date)))
                .collect(Collectors.toList());
    }

    public Optional<Booking> getBookingById(Long bookingId) {
        return bookingRepository.findById(bookingId);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public void deleteBooking(Long bookingId) {
        bookingRepository.deleteById(bookingId);
    }
}

